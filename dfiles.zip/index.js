import Layout from '../../components/users/layout'

import '../../assets/reset.css'
import "../../assets/users/style.css"
import "../../assets/users/responsive.css"

function HomePage() {
  return <Layout></Layout>
}

export default HomePage
